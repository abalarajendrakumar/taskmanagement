const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const userSchema = mongoose.Schema({
  email: { type: String, required: true, unique: true },
  Password: { type: String, required: true },
  StoreName: { type: String, required: true},
  VendorName:{ type: String, required: true},
  Location: { type: String, required: true},
  Landmark: { type: String, required: true},
  Contactno: { type: String, required: true},
  imagepath: { type: String, required: true}

});

userSchema.plugin(uniqueValidator);

module.exports = mongoose.model("User", userSchema);
