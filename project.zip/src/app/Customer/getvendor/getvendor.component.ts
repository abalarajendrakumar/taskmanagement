import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getvendor',
  templateUrl: './getvendor.component.html',
  styleUrls: ['./getvendor.component.css']
})
export class GetvendorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
