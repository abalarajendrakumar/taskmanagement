import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetvendorComponent } from './getvendor.component';

describe('GetvendorComponent', () => {
  let component: GetvendorComponent;
  let fixture: ComponentFixture<GetvendorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetvendorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetvendorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
