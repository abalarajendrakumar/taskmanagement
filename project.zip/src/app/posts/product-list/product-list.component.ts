import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../auth/auth.service';
import { PostsService } from '../posts.service';
import { mimeType } from "./mime-type.validator";

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})


export class ProductListComponent implements OnInit {

  form: any;
  imagePreview: string | ArrayBuffer;

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
  }
  constructor(public authService:AuthService,public route: ActivatedRoute) { 
  }

  ngOnInit() {

    this.form=new FormGroup({
      StoreName: new FormControl(null,{validators:[Validators.required]}),
      VendorName: new FormControl(null,{validators:[Validators.required]}),
      email: new FormControl(null,{validators:[Validators.required]}),
      Contactno:new FormControl(null,{validators:[Validators.required]}),
      Location: new FormControl(null,{validators:[Validators.required]}),
      Landmark: new FormControl(null,{validators:[Validators.required]}),
      Password: new FormControl(null,{validators:[Validators.required]}),
      ConfirmPassword: new FormControl(null,{validators:[Validators.required]}), 
      image: new FormControl(null, {
        validators: [Validators.required],
        asyncValidators: [mimeType]
      })
    });
  }
  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.form.patchValue({ image: file });
    this.form.get("image").updateValueAndValidity();
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    };
    reader.readAsDataURL(file);
  }
  
  register()
  {
    console.log(this.form.value);
    this.authService.createUser(this.form.value.email,this.form.value.Password,this.form.value.StoreName,this.form.value.VendorName,this.form.value.Contactno,this.form.value.Location,this.form.value.Landmark,this.form.value.image);

  }


}
