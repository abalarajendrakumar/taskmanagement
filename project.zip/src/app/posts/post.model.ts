export interface Post {
  id: string;
  title: string;
  content: string;
  ProductId:string;
  Price:string;
  imagePath: string;
  creator: string;
}
